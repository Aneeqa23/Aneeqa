import serial
import re;
from Speak import *
from gui import *

arduino = serial.Serial(port='COM4', baudrate=9600, timeout=.1)


def TemperatureCheck():
    Check_Temperature_ins()
    while True:
        ser = arduino.readline().decode()
        numbers = re.findall('\d+', ser)  # find numbers from stings
        if numbers:
            print("Temparture (F) = " + numbers[1])
            serInt = int(numbers[1])  # convert F temperature into stings

            if serInt<=105:
                speak("Thank you! Your Body Temperature Is Normal please senitize YourSelf.")
                Normal_Temperature_ins()
                break

            else:
                speak("Your Body temperature is not reliable!")
                break;