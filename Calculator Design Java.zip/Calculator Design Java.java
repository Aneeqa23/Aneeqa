import javax.swing.*; 
import java.awt.*;


 public class maryam  {
  public static void main(String args[]){
   
  JFrame home=new JFrame("calculator");
  home.setSize(290,450); 
  home.setLayout(null); 
  home.setVisible(true);
  JTextField Txt=new JTextField();
  home.add(Txt);
  Txt.setBounds(15,30,240,55);
   
  JButton btn0=new JButton("0"); 
  btn0.setBounds(20,340,100,50); 
  home.add(btn0); 
  
    
 JButton btn2=new JButton("2");
 btn2.setBounds(75,295,50,40);
 home.add(btn2);  
  
 JButton btn1=new JButton("1");
 btn1.setBounds(125,350,80,40);
 home.add(btn1); 
  
 JButton btn3=new JButton("3");
 btn3.setBounds(20,295,50,40);
 home.add(btn3);
  
 JButton btn4=new  JButton("4");
 btn4.setBounds(20,250,50,40); 
 home.add(btn4);
 JButton btn5=new  JButton("5");
 btn5.setBounds(75,250,50,40); 
 home.add(btn5);
 JButton btn6=new  JButton("6");
 btn6.setBounds(20,200,50,40); 
 home.add(btn6);
 JButton btn7=new  JButton("7");
 btn7.setBounds(75,200,50,40); 
 home.add(btn7);
 JButton btn8=new  JButton("8");
 btn8.setBounds(20,150,50,40); 
 home.add(btn8);
 JButton btn9=new  JButton("9");
 btn9.setBounds(75,150,50,40); 
 home.add(btn9); 
 JButton btn_Dot=new  JButton(".");
 btn_Dot.setBounds(210,350,50,40); 
 home.add(btn_Dot);
 JButton btn_minus=new  JButton("-");
 btn_minus.setBounds(130,295,70,50); 
 home.add(btn_minus);
 
 JButton btn_plus=new  JButton("+");
 btn_plus.setBounds(210,260,50,80); 
 home.add(btn_plus);
 
  JButton btn_division=new  JButton("/");
 btn_division.setBounds(130,240,70,50); 
 home.add(btn_division); 
  
 JButton btn_on=new  JButton("On");
 btn_on.setBounds(130,190,70,40); 
 home.add(btn_on); 
 btn_on.setBackground(Color.ORANGE);

 JButton btn_isequalto=new  JButton("=");
 btn_isequalto.setBounds(210,210,50,40); 
 home.add(btn_isequalto); 
 
 JButton btn_off=new  JButton("off");
 btn_off.setBounds(130,150,70,30); 
 home.add(btn_off);  
 btn_off.setBackground(Color.GRAY);
 JButton btn_multiply=new  JButton("x");
 btn_multiply.setBounds(210,150,50,55); 
 home.add(btn_multiply); 
 JLabel lbl=new JLabel("Designed by Aneeqa");
 home.add(lbl); 
 lbl.setBounds(20,90,170,70);  
 
 



 
   
   
 
 
 
  
  
  
  
  

  
}
 }
 
    